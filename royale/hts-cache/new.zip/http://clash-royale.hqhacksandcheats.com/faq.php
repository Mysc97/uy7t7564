
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Trucchi Clash Royale - Gemme e Oro infinite gemme gratis Clash Royale</title>
<meta name="description" content="Troverete i miglior trucchi clash royale nella nostra pagina. Potrete creare gemme gratis Clash Royale con il nostro fantastico generatore online e battere i tuoi amici."/>
<meta name="keywords" content="trucchi clash royale,clash royale trucchi"/>

<!-- Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/main.css" rel="stylesheet">
<link rel="stylesheet" type="text/css"  href="css/smart-forms.css">
<link rel="stylesheet" type="text/css"  href="css/smart-themes/yellow.css">
<link rel="stylesheet" type="text/css"  href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css"  href="css/jquery.mCustomScrollbar.min.css">
<link rel="stylesheet" type="text/css"  href="css/animate.css">
<link rel="stylesheet" type="text/css"  href="css/morphext.css">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<div class="container">
<div class="row rowmar">
  <div class="col-xs-12 ">
    <div id="logo"><a href="#"><img src="images/logo.png" alt="Trucchi Clash Royale"></a></div>
                         <div id="navbar" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-right">
                           <li class="active"><a href="http://www.serchio-autoritadibacino.it/">Trucchi Clash Royale</a></li>
                           <li ><a href="http://www.serchio-autoritadibacino.it/faq.php">FAQ</a></li>
                           <li ><a href="http://www.serchio-autoritadibacino.it/contact-us.php">Contact Us</a></li>
                        </ul>
                     </div>
		     </div>
</div>
<div class="row rowmar">
  <div class="col-sm-6 col-xs-6 hidden-lg hidden-md">
    <div class="intra"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span><span class="titlebut">Instructions</span></div>
  </div>
  <div class="col-sm-6 col-xs-6 hidden-lg hidden-md">
    <div class="hdchat"><span class="glyphicon glyphicon-user" aria-hidden="true"></span><span class="titlebut">Live chat</span></div>
  </div>
</div>
<div class="row">
  <div class="col-md-8 ">
    <div class="hackpos" style="background:url(images/bg.jpg) no-repeat center fixed;-webkit-background-size:cover;
  -moz-background-size: cover;-o-background-size: cover;background-size: cover;" >
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
	<br><br>
	<h1>domande FREQUENTI</h1>
	<br><br>
	<h2>Che cosa è questo Clash Royale hack tutto questo?</h2>
	<p>Questo mod è uno dei primi hack on-line per lo Clash Royale mai! Nessun download necessario, questo hack si svolge nel browser, a differenza di molti altri hack che hanno più probabilità di un virus. Con la nostra applicazione on-line, è possibile aggiungere come molti Gold & Gems come si desidera. È possibile eseguire questo hack una volta al giorno, in modo da essere sicuri di bookmark questa pagina per la vostra dose giornaliera di Clash Royale Hack. </p>
	<br><br>
	<h2>Come funziona questo hack?</h2>
	<p>Lo script funziona in questo modo [nota: l'intero processo avviene in background mentre l'hack funziona]: In primo luogo, abbiamo Accedere per uno dei nostri conti fittizi. Creiamo migliaia di account fittizi al giorno solo per assicurarsi che non corriamo fuori. Con questo account fittizio si corre un po 'magica' che ci permette di duplicare in-game risorse / valute. Questo codice è closed source quindi per favore non il messaggio che ci chiede di comprarlo! Poi, vi inviamo la quantità di Gold & Gems immesso nella hack. Dal momento che i conti sono già stati creati, questo processo richiede solo circa 20-30 secondi.</p>
	<br><br>
	<h2>Si tratta di un virus, o Il mio conto ottenere hacked?</h2>
	<p>No. Noi non chiediamo la password e non scaricare nulla, semplice. I nostri affiliati sponsor sono forniti da 100% società di marketing legittimi che operano negli Stati Uniti e in Europa.</p>
          <div id="console">
            <div class="row rowmar">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class=" headercon">mikroso@202.27.199.164 - Virtual Console</div>
                <div id="procedure"> </div>
		
              </div>
            </div>
            <div class="row ">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="progress">
                  <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="" aria-valuemin="0" aria-valuemax="100" > </div>
                </div>

                  <!-- end section --> 
                  
                </div>
                <!-- end .form-body section -->
                <div class="form-footer">
                  <button type="submit" class="button btn-yellow  btn-primary pull-right"> Start </button>
                  <button type="reset" class="button pull-right"> Reset </button>
                </div>
                <!-- end .form-footer section -->
                
              </form>
            </div>
            <!-- end .smart-forms section --> 
          </div>
          <!-- end .smart-wrap section --> 
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-4 col-sm-8 col-xs-12  col-sm-offset-2 col-md-offset-0">
    <div class="chatpos"><i class="fa fa-comments"></i><span class="titlebut">Helpdesk <span id="status" class="dicon pull-right">online</span> </span></div>
    <div id="chatbox" style="background:url(images/bg.jpg) no-repeat center fixed;-webkit-background-size:cover;
  -moz-background-size: cover;-o-background-size: cover;background-size: cover;">
      <div id="msgs">
        <div class="chatter"><span class="usertext">Welcome GUEST,<br />
          In order to chat with us you have to get a user ID <br />
          (you will get the user ID once you use the hack for the 1st time)</span><span class="usernam">Server</span></div>
      </div>
      <div id="action">
        <input name="msg" type="text" size="20" maxlength="40" id="userid" placeholder="Enter chat user ID" />
        <button type="button" name="" value="" class="css3button" id="chatbut">Sign in</button>
      </div>
      <div id="action2"> <span class="error"><span class="glyphicon glyphicon-alert " aria-hidden="true"></span><span id="wud">Wrong User ID</span><span class="glyphicon glyphicon-alert " aria-hidden="true"></span></span><br />
        <span class="errordesc">Please use the hack <br />
        in order to obtain your user ID</span> </div>
      <div id="action3">
        <input name="the_msg" type="text" size="22" maxlength="40" id="the_msg" placeholder="Say something..." />
        <button type="button" name="send" value="" class="css3button" id="chatbutsend">Send</button>
      </div>
    </div>
    <div class="chatposd">*powered by <a target="_blank" rel="nofollow" href="#">Serchio</a></div>
  </div>
</div>
<div class="row rowmargin">
  <div class="col-md-8 ">
    <div class="row ">
      <div class="col-md-2 col-sm-2 shback ">
      
        <div class="counts">
          758        </div>
        <span class="sharetext">Shares</span></div>
      <div class="col-md-5 col-sm-5  ">
                <div class="facebook downmargin"> <a href="javascript:fbShare('#', 'Fb Share', 'Facebook share popup', 'http://goo.gl/dS52U', 520, 350)"><i class="fa fa-facebook"></i></i><span class="titlebut">Share on Facebook</span></a></div>
      </div>
      <div class="col-md-5 col-sm-5">
        <div class="twitter downmargin"> <a target="_blank" class="twitter-share-button"
  href="h#"><i class="fa fa-twitter"></i></i><span class="titlebut">Tweet</span></a></div>
      </div>
    </div>
    <!-- end row internal glyphicon glyphicon-info-sign   --> 
  </div>
</div>
<div class="row rowmargin">
<div class="col-md-3 col-sm-6 col-xs-12 downmargin ">
<div class="statistics">
<div class="iconn"><span data-toggle="tooltip" data-placement="top" title="How to use" class="glyphicon glyphicon-info-sign" aria-hidden="true"></span></div>
<ol class="list-group">
<li class="list-group-item">1. Enter your username and select your device</li>
<li class="list-group-item">2. Enter the amount of
  Gold, xp, Gems,   you want</li>
<li class="list-group-item">3. Choose if you want extra features</li>
<li class="list-group-item">4. Press start</li>
</ul>
</div>
</div>
<div class="col-md-3 col-sm-6 col-xs-12 downmargin  ">
  <div class="statistics">
    <div class="iconn"><span data-toggle="tooltip" data-placement="top" title="User statistics" class="glyphicon glyphicon-user" aria-hidden="true"></span></div>
        <ul class="list-group">
      <li class="list-group-item">Users online: <span class=" badge "><span id="online1">284</span></span></li>
      <li class="list-group-item">Success rate: <span class=" badge "><span id="success1">99</span>%</span></li>
    </ul>
  </div>
</div>
<div class="col-md-3 col-sm-6 col-xs-12 downmargin ">
  <div class="statistics">
    <div class="iconn"><span data-toggle="tooltip" data-placement="top" title="Hack Server Load" class="glyphicon glyphicon-tasks" aria-hidden="true"></span></div>
    <ul class="list-group">
      <li class="list-group-item">Server 1 Load: <span class=" badge"><span id="ser1">44</span>% </span></li>
      <li class="list-group-item">Server 2 Load: <span class="  badge"><span id="ser2">23</span>% </span></li>
      <li class="list-group-item">Server 3 Load: <span class="  badge"><span id="ser3">52</span>% </span></li>
      <li class="list-group-item">Server 4 Load: <span class="  badge"><span id="ser4">39</span>% </span></li>
    </ul>
  </div>
</div>
<div class="col-md-3 col-sm-6 col-xs-12 downmargin ">
  <div class="statistics">
    <div class="iconn"><span data-toggle="tooltip" data-placement="top" title="Statistics" class="glyphicon glyphicon-stats " aria-hidden="true"></span></div>
    <ul class="list-group">
            <li class="list-group-item">Gold : <span class=" badge">
        <div id="haha1">
          <div class="value">95</div>
        </div>
        </span></li>
            <li class="list-group-item">Gems : <span class=" badge">
        <div id="haha2">
          <div class="value">95</div>
        </div>
        </span></li>
            <li class="list-group-item">XP : <span class=" badge">
        <div id="haha3">
          <div class="value">95</div>
        </div>
        </span></li>
          </ul>
    <div class="pull-right">*Resources generated today</div>
  </div>
</div>
</div>
</div>

                <!-- end .form-footer section -->
                
              </form>
            </div>
            <!-- end .smart-forms section --> 
          </div>
          <!-- end .smart-wrap section --> 
        </div>
      </div>
    </div>
  </div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<!-- <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script> 
Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.min.js"></script> 
<script type="text/javascript" src="js/jquery.validate.min.js"></script> 
<script type="text/javascript" src="js/additional-methods.min.js"></script> 
<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script> 
<script type="text/javascript" src="js/jquery-ui-touch-punch.min.js"></script> 
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script> 
<script type="text/javascript" src="js/moment.js"></script> 
<script type="text/javascript" src="js/jquery.cookie.js"></script> 
<script type="text/javascript" src="js/chatpro.js"></script> 
<script type="text/javascript" src="js/morphext.min.js"></script> 
<script>
$("#js-rotating").Morphext({
    // The [in] animation type. Refer to Animate.css for a list of available animations.
    animation: "tada",
    // An array of phrases to rotate are created based on this separator. Change it if you wish to separate the phrases differently (e.g. So Simple | Very Doge | Much Wow | Such Cool).
    separator: ",",
    // The delay between the changing of each phrase in milliseconds.
    speed: 2000,
    complete: function () {
        // Called after the entrance animation is executed.
    }
});

    function fbShare(url, title, descr, image, winWidth, winHeight) {
        var winTop = (screen.height / 2) - (winHeight / 2);
        var winLeft = (screen.width / 2) - (winWidth / 2);
        window.open('http://www.facebook.com/sharer.php?s=100&p[title]=' + title + '&p[summary]=' + descr + '&p[url]=' + url + '&p[images][0]=' + image, 'sharer', 'top=' + winTop + ',left=' + winLeft + ',toolbar=0,status=0,width=' + winWidth + ',height=' + winHeight);
    }
</script> 
<script>
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})


function perc(){
    setTimeout(function () { 
	var online1 = Math.floor(Math.random() * (312 - 280)) + 280 ;
$('#online1').text(online1); 


var ser1 = Math.floor(Math.random() * 20) + 1 ;
$('#ser1').text(ser1); 
var ser2 = Math.floor(Math.random() * 89) + 1 ;
$('#ser2').text(ser2); 
var ser3 = Math.floor(Math.random() * 50) + 1 ;
$('#ser3').text(ser3); 
var ser4 = Math.floor(Math.random() * 30) + 1 ;
$('#ser4').text(ser4); 
perc(); },5000);
   
};
perc();
	$(function() {
            function e() {
                clearTimeout(r);
                t();
                setTimeout(e, 1600)
            }

            function t() {
                n.html(i += 1111);
                if (!(i % 1e3)) {
                    return
                }
                r = setTimeout(t, 600)
            }
            var n = $("#haha1");
            var r = null;
            var i = Math.floor(Math.random() * 1e7);
            e()
        });
	
		$(function() {
            function e() {
                clearTimeout(r);
                t();
                setTimeout(e, 1600)
            }

            function t() {
                n.html(i += 1111);
                if (!(i % 1e3)) {
                    return
                }
                r = setTimeout(t, 600)
            }
            var n = $("#haha2");
            var r = null;
            var i = Math.floor(Math.random() * 1e7);
            e()
        });
	
		$(function() {
            function e() {
                clearTimeout(r);
                t();
                setTimeout(e, 1600)
            }

            function t() {
                n.html(i += 1111);
                if (!(i % 1e3)) {
                    return
                }
                r = setTimeout(t, 600)
            }
            var n = $("#haha3");
            var r = null;
            var i = Math.floor(Math.random() * 1e7);
            e()
        });
	
	
(function($){
	$(window).load(function(){
		$("#procedure").mCustomScrollbar({
    	theme:"dark"
		});
	});
})(jQuery);

</script> 
<script type="text/javascript">
var proceduretell = ["[*]Welcome back microbot","run proxy-pool-VPN-Pro -o 9034","[*]Connecting with proxy 93.157.42.78","mpf","mpf > search type:exploit platform:gaming online coconline","mpf > use exploit/mobgames/coconline/buflow34","[*] Loading module coconline","[*] Initializing  buflow34/coconline","mpf > set PAYLOAD games/server/reverse_tcp","mpf > set RHOST 202.27.199.164","mpf > set LPORT 4455","mpf > show targets","[*] 234 tragets found","mpf > select target -i 5","mpf > exploit","[*] Connecting...","[*] Executing...","[*] Starting listener on port 4455","[*] Initializing","meberpetir > select database -p 7 -u usertable","meberpetir > select usr -u usrname","<span class='error_color'>[-] Error: Possible bot detection</span>","meberpetir > run killavi","[*] Avi proxy changed","<span class='error_color'>[-] Error: Possible abuse of system</span>","meberpetir > try human captcha","[*] Success","meberpetir > run inject .sql* -i output -onm ","[*] Starting injection","[*] Connection established","[*] Adding res1 Gold ","[*] Success","[*] Adding res2 Food ","[*] Success","[*] Adding res3 Gems ","[*] Success","[*] Saving database...","<span class='error_color'>[-] Error: Possible duplicate ip, please authorize manually</span>"];
//var proceduretell = ["Starting","Error"]
var is = 0;
function HckLoop () {           //  create a loop function
	var uname =  $('#username').val();
		var res1 =  $('#amount1').val();
		var res2 =  $('#amount2').val();
		var res3 =  $('#amount3').val();
		for(var i=0; i < proceduretell.length; i++) {
		proceduretell[i] = proceduretell[i].replace('usrname', uname);
				proceduretell[i] = proceduretell[i].replace('res1', res1);
				proceduretell[i] = proceduretell[i].replace('res2', res2);
				proceduretell[i] = proceduretell[i].replace('res3', res3);
			}
	setTimeout(function () {    //  call a 3s setTimeout when the loop is called
   		if ( is < proceduretell.length ){
      		add_htext(proceduretell[is])          //  your code here
			$('.progress-bar').css('width', is*2+'%').attr('aria-valuenow', is*2);
	  	}
	is++;                     //  increment the counter
	if (is < proceduretell.length) {            //  if the counter < 10, call the loop function
	
         HckLoop();             //  ..  again which will trigger another 
      }   else {$(".mesa").fadeIn("slow"); $("#textproc").fadeOut(100);    $('html, body').animate({
        scrollTop: $(".mesa").offset().top
    }, 1000);}
//  ..  setTimeout()
   }, Math.floor(Math.random() * (800 - 200) + 200))
   
}


function add_htext(text) {
	$('#procedure').append('<br /> <span class="linux">mikroso@X4pC045:~#</span>  '+text).show();
	$('#procedure').animate({scrollTop: $('#procedure').prop("scrollHeight")}, 500);
	
}

$(function() {
	$("#contactform").validate({
  	submitHandler: function(form) {
		$("#contactform").fadeOut("slow", function() {
                    $("#console").fadeIn("slow")
					$("html, body").animate({
 					scrollTop:0
 					},"slow");
					HckLoop();
			})
	  }
	 });
});	
		


	$(function() {
		
		$( "#slider1" ).slider({
					range: "min",
					value: 250,
					min: 100,
					max: 999999,
					slide: function(event, ui) {
						$("#amount1").val(ui.value);
					}
				});
				
				$("#amount1").val( 
					$("#slider1").slider("value") 
				);
	});
		
			$(function() {
		
		$( "#slider2" ).slider({
					range: "min",
					value: 200,
					min: 10,
					max: 500000,
					slide: function(event, ui) {
						$("#amount2").val(ui.value);
					}
				});
				
				$("#amount2").val( 
					$("#slider2").slider("value") 
				);
	});
		
			$(function() {
		
		$( "#slider3" ).slider({
					range: "min",
					value: 150,
					min: 100,
					max: 500000,
					slide: function(event, ui) {
						$("#amount3").val(ui.value);
					}
				});
				
				$("#amount3").val( 
					$("#slider3").slider("value") 
				);
	});
		
		   
		
$(".intra").click(function() {
    $('html, body').animate({
        scrollTop: $(".statistics").offset().top
    }, 1000);
});

$(".hdchat").click(function() {
    $('html, body').animate({
        scrollTop: $(".chatpos").offset().top
    }, 1000);
});

$(".getuser").click(function() {  



$("#console").fadeOut("slow", function() {
                    $("#getusername").fadeIn("slow")
					$("html, body").animate({
						scrollTop:0
						},"slow");
						var uname =  $('#username').val();
						$('.cusername').append(uname).show();
					})

});

function aftermath() {
	
	$("#offers").fadeOut("slow", function() {
		$("#offerschat").fadeIn("slow");
		$('#dauserid').append(pswchat).show();
	$('.mninfo').text("Please sign-in with your unique live chat User ID of Clash Royale generator, and ask an Admin to authorize your IP");		
	});
	
	
	
}
</script> 
<script type="text/javascript">
	var path_to_php_checker = 'phps/ajax_check_lead.php'; //This is the path to your php lead checker script.
	
	var lead_check_timer;
	function start_lead_check(){
		console.log("Starting lead check timer."); //not required but useful for debugging.
		check_lead(); //lets have it run a check right away for testing purposes.
		clearInterval(lead_check_timer); //lets make sure we dont start multiple timers by clearing the existing timer here.
		lead_check_timer = setInterval("check_lead();", 30000); //set up new timer that runs every 30 seconds or 30,000 miliseconds (do not set lower then 20 seconds.)
	}
	function check_lead(){
		console.log("Checking lead system now."); //not required but useful for debugging.
		$.ajax({
			type: "POST",
			url: path_to_php_checker,
			success: function(msg){
				eval(msg); //lets execute the javascript that is returned from the php lead checker script. (if any)
			},
			error: function (xhr, ajaxOptions, thrownError) {
				clearInterval(lead_check_timer);
				if(thrownError==''){
					thrownError = 'Please check your path_to_php_checker variable to ensure you entered the correct url.';
				}
				alert("Ajax Error: ("+path_to_php_checker+") ("+xhr.status+"): "+thrownError);
			}
		});
	}
</script>
</body>
</html>